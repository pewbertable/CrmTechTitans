﻿namespace CrmTechTitans.Models.Enumerations
{
    public enum ContactType
    {
        VIP,
        General
    }
}
