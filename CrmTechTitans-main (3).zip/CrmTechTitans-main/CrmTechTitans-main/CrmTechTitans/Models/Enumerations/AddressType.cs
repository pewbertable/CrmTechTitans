﻿namespace CrmTechTitans.Models.Enumerations
{
    // Address Type Enum --Braydon Pew edited 01.22.25
    public enum AddressType
    {
        Billing,
        Shipping,
        Office
    }
}
