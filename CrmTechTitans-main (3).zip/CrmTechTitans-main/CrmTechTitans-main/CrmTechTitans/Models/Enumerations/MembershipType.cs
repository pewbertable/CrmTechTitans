﻿namespace CrmTechTitans.Models.Enumerations
{
    public enum MembershipType
    {
        Associate,
        ChamberAssociate,
        GovernmentEducationAssociate,
        Localindustrial,
        NonLocalIndustrial
    }
}
