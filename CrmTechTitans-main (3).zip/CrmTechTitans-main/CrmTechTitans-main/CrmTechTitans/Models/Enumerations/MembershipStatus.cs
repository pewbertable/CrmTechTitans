﻿namespace CrmTechTitans.Models.Enumerations
{
    public enum MembershipStatus
    {
        Active,
        Inactive,
    }
}
