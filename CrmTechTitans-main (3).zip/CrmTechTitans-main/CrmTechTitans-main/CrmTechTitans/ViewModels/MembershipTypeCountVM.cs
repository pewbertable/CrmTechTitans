﻿namespace CrmTechTitans.ViewModels
{
    public class MembershipTypeCountVM
    {

        public int AssociateCount { get; set; }
        public int ChamberAssociateCount { get; set; }
        public int NonLocalIndustrialCount { get; set; }
        public int GovernmentAssociationCount { get; set; }
        public int LocalCount { get; set; }
        public int OtherCount { get; set; }
    }
}
