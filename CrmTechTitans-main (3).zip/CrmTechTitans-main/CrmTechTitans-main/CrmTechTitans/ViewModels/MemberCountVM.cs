﻿namespace CrmTechTitans.ViewModels
{
    public class MemberCountVM
    {
        public string Membership { get; set; }
        public int TotalMembers { get; set; }
        public int ActiveMembers { get; set; }
        public int InactiveMembers { get; set; }
    }
}
