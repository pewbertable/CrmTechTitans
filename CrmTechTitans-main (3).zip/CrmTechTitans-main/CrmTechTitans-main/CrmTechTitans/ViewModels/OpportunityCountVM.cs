﻿namespace CrmTechTitans.ViewModels
{
    public class OpportunityCountVM
    {
        public int QualificationCount { get; set; }
        public int NegotiationCount { get; set; }
        public int ClosedNewMembersCount { get; set; }
        public int ClosedNotInterestedCount { get; set; }
    }
}
